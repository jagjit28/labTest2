const mongoose = require('mongoose')
const userSchema = mongoose.Schema(
    {
        name:{
            type : String,
            required : [true, "please enter name"]
        },
        email:{
            type: String,
            unique: true,
            required : [true, "please enter email"]
        },
        password:{
            type: String,
            required : [true, "please enter password"]
        }
    },
    {
        timestamps : true
    }
)
const User = mongoose.model('User', userSchema);
module.exports = User;
