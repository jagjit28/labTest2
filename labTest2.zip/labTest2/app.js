require("dotenv").config();
require("./config/database").connect();
const express = require("express");
const User = require('./models/userModels')
const app = express();
const fs = require('fs');

var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  const data = fs.readFileSync('./public/pages/index.html');
  res.send(data.toString());
})
app.post('/randomText', (req, res) => {
  var myData = new User(req.body);
  try{
    myData.save()
    console.log("data saved")
  }catch{
    console.log("data not saved")
  }
  
  const data = fs.readFileSync('./public/pages/index.html');
  res.send(data.toString());
})



module.exports = app;